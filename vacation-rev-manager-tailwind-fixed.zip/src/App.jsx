import React, { useState, useMemo } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts';

function generateMockCalendar(baseRate) {
  const arr = [];
  const start = new Date('2025-08-01');
  for (let i = 0; i < 31; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    const occupancy = Math.max(0, Math.min(1, 0.6 + Math.sin(i/5) * 0.25));
    arr.push({ date: d.toISOString().slice(0,10), rate: baseRate, occupancy });
  }
  return arr;
}

const mockProperties = [
  { id: 'p1', name: 'Sea View Studio — Supetar', location: 'Supetar, Brač, Croatia', beds: 2, baseRate: 80, calendar: generateMockCalendar(80), suggestedRates: [] },
  { id: 'p2', name: 'Cozy 2BR — Split', location: 'Split, Croatia', beds: 4, baseRate: 120, calendar: generateMockCalendar(120), suggestedRates: [] },
];

export default function App(){
  const [properties, setProperties] = useState(mockProperties);
  const [selectedPropertyId, setSelectedPropertyId] = useState(properties[0].id);
  const selectedProperty = useMemo(()=> properties.find(p=>p.id===selectedPropertyId), [properties, selectedPropertyId]);
  const [priceMultiplier, setPriceMultiplier] = useState(1.0);

  function runPricingEngine(){
    const newProperties = properties.map(p=>{
      if(p.id !== selectedPropertyId) return p;
      const next = {...p};
      next.suggestedRates = p.calendar.map(day=>{
        const dayOfWeek = new Date(day.date).getDay();
        const isWeekend = dayOfWeek === 5 || dayOfWeek === 6;
        const occupancyFactor = 1 - day.occupancy;
        const suggested = Math.round((p.baseRate * priceMultiplier * (isWeekend ? 1.12 : 1.0)) * (1 - occupancyFactor * 0.25));
        return { ...day, suggestedRate: suggested };
      });
      return next;
    });
    setProperties(newProperties);
  }

  function applySuggestedRatesToCalendar(){
    const newProperties = properties.map(p=>{
      if(p.id !== selectedPropertyId) return p;
      return {...p, calendar: p.suggestedRates.length ? p.suggestedRates.map(d=>({...d, rate: d.suggestedRate})) : p.calendar};
    });
    setProperties(newProperties);
  }

  return (
    <div className="min-h-screen p-6 bg-slate-50 text-slate-900">
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">Vacation Rental Revenue Manager</h1>
        <p className="text-sm text-slate-600">Prototype dashboard — properties, calendar pricing, forecasts</p>
      </header>

      <main className="grid grid-cols-12 gap-6">
        <section className="col-span-3 bg-white p-4 rounded-2xl shadow-sm">
          <h2 className="font-medium">Properties</h2>
          <ul className="mt-3 space-y-2">
            {properties.map((p) => (
              <li key={p.id} className={\`p-2 rounded-lg cursor-pointer \${p.id === selectedPropertyId ? 'bg-slate-100' : ''}\`} onClick={() => setSelectedPropertyId(p.id)}>
                <div className="flex justify-between items-center">
                  <div>
                    <div className="font-semibold">{p.name}</div>
                    <div className="text-xs text-slate-500">{p.location}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm">€{p.baseRate}</div>
                    <div className="text-xs text-slate-400">{p.beds} bd</div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </section>

        <section className="col-span-6 bg-white p-4 rounded-2xl shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-lg font-semibold">{selectedProperty.name}</h2>
              <div className="text-sm text-slate-500">{selectedProperty.location} • {selectedProperty.beds} beds</div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-500">Base rate</div>
              <div className="text-xl font-semibold">€{selectedProperty.baseRate}</div>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="p-3 border rounded-lg">
              <label className="text-xs">Multiplier</label>
              <div className="mt-2 flex items-center gap-2">
                <input type="range" min="0.6" max="1.6" step="0.01" value={priceMultiplier} onChange={(e)=>setPriceMultiplier(Number(e.target.value))} className="w-full" />
                <div className="w-16 text-right">{priceMultiplier.toFixed(2)}x</div>
              </div>
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <button className="px-4 py-2 rounded-xl bg-slate-900 text-white text-sm" onClick={runPricingEngine}>Run pricing engine</button>
            <button className="px-4 py-2 rounded-xl border text-sm" onClick={applySuggestedRatesToCalendar}>Apply suggested rates</button>
          </div>

          <div className="mt-6">
            <h3 className="font-medium mb-2">Calendar (sample)</h3>
            <div className="grid grid-cols-3 gap-2">
              {selectedProperty.calendar.slice(0,9).map((d)=>(
                <div key={d.date} className="p-2 border rounded">
                  <div className="text-xs text-slate-500">{d.date}</div>
                  <div className="text-sm">Rate: €{d.rate}</div>
                  <div className="text-xs text-slate-400">Suggested: €{(selectedProperty.suggestedRates.find(s=>s.date===d.date)?.suggestedRate) ?? d.rate}</div>
                  <div className="text-xs mt-1">Occ: {(d.occupancy*100).toFixed(0)}%</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <aside className="col-span-3 bg-white p-4 rounded-2xl shadow-sm">
          <h3 className="font-medium">Forecast</h3>
          <div style={{ height: 220 }} className="mt-3">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={selectedProperty.calendar.map(d=>({ date: d.date.slice(5), rev: d.rate * (1 - d.occupancy) }))}>
                <XAxis dataKey="date" />
                <YAxis />
                <CartesianGrid strokeDasharray="3 3" />
                <Tooltip />
                <Line type="monotone" dataKey="rev" stroke="#8884d8" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </aside>
      </main>
    </div>
  );
}
